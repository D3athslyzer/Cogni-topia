"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { FileText, RotateCcw, Home, Clock, CheckCircle } from "lucide-react"
import Link from "next/link"

interface SentencePuzzle {
  id: number
  scrambledWords: string[]
  correctSentence: string
  difficulty: "Easy" | "Medium" | "Hard"
  topic: string
}

export default function VerbalReasoningGame() {
  const [currentPuzzle, setCurrentPuzzle] = useState<SentencePuzzle | null>(null)
  const [userSentence, setUserSentence] = useState<string[]>([])
  const [availableWords, setAvailableWords] = useState<string[]>([])
  const [score, setScore] = useState(0)
  const [level, setLevel] = useState(1)
  const [timeLeft, setTimeLeft] = useState(120) // 2 minutes
  const [puzzlesCompleted, setPuzzlesCompleted] = useState(0)
  const [gameStatus, setGameStatus] = useState<"playing" | "finished">("playing")
  const [gameStarted, setGameStarted] = useState(false)
  const [feedback, setFeedback] = useState<"correct" | "incorrect" | null>(null)

  const sentencePuzzles: SentencePuzzle[] = [
    {
      id: 1,
      scrambledWords: ["the", "quickly", "brown", "fox", "jumps", "over", "lazy", "dog"],
      correctSentence: "The brown fox jumps quickly over the lazy dog.",
      difficulty: "Easy",
      topic: "Animals",
    },
    {
      id: 2,
      scrambledWords: ["technology", "has", "revolutionized", "the", "way", "we", "communicate", "today"],
      correctSentence: "Technology has revolutionized the way we communicate today.",
      difficulty: "Medium",
      topic: "Technology",
    },
    {
      id: 3,
      scrambledWords: [
        "sustainable",
        "development",
        "requires",
        "balancing",
        "economic",
        "growth",
        "with",
        "environmental",
        "protection",
      ],
      correctSentence: "Sustainable development requires balancing economic growth with environmental protection.",
      difficulty: "Hard",
      topic: "Environment",
    },
    {
      id: 4,
      scrambledWords: ["education", "is", "the", "key", "to", "unlocking", "human", "potential"],
      correctSentence: "Education is the key to unlocking human potential.",
      difficulty: "Medium",
      topic: "Education",
    },
    {
      id: 5,
      scrambledWords: [
        "artificial",
        "intelligence",
        "will",
        "transform",
        "many",
        "industries",
        "in",
        "the",
        "coming",
        "decades",
      ],
      correctSentence: "Artificial intelligence will transform many industries in the coming decades.",
      difficulty: "Hard",
      topic: "Technology",
    },
    {
      id: 6,
      scrambledWords: ["reading", "books", "expands", "your", "vocabulary", "and", "imagination"],
      correctSentence: "Reading books expands your vocabulary and imagination.",
      difficulty: "Easy",
      topic: "Literature",
    },
    {
      id: 7,
      scrambledWords: ["global", "warming", "poses", "significant", "challenges", "for", "future", "generations"],
      correctSentence: "Global warming poses significant challenges for future generations.",
      difficulty: "Medium",
      topic: "Environment",
    },
    {
      id: 8,
      scrambledWords: ["effective", "communication", "requires", "both", "listening", "and", "speaking", "skills"],
      correctSentence: "Effective communication requires both listening and speaking skills.",
      difficulty: "Medium",
      topic: "Communication",
    },
  ]

  const generatePuzzle = () => {
    const availablePuzzles = sentencePuzzles.filter(
      (p) =>
        (level <= 2 && p.difficulty === "Easy") ||
        (level <= 4 && p.difficulty === "Medium") ||
        (level > 4 && p.difficulty === "Hard"),
    )

    const puzzle = availablePuzzles[Math.floor(Math.random() * availablePuzzles.length)]
    const shuffledWords = [...puzzle.scrambledWords].sort(() => Math.random() - 0.5)

    setCurrentPuzzle(puzzle)
    setAvailableWords(shuffledWords)
    setUserSentence([])
  }

  const initializeGame = () => {
    generatePuzzle()
    setScore(0)
    setLevel(1)
    setTimeLeft(120)
    setPuzzlesCompleted(0)
    setGameStatus("playing")
    setGameStarted(true)
    setFeedback(null)
  }

  const addWordToSentence = (word: string, index: number) => {
    setUserSentence((prev) => [...prev, word])
    setAvailableWords((prev) => prev.filter((_, i) => i !== index))
  }

  const removeWordFromSentence = (index: number) => {
    const word = userSentence[index]
    setUserSentence((prev) => prev.filter((_, i) => i !== index))
    setAvailableWords((prev) => [...prev, word])
  }

  const checkSentence = () => {
    if (!currentPuzzle || userSentence.length === 0) return

    const userSentenceText = userSentence
      .join(" ")
      .toLowerCase()
      .replace(/[.,!?]/g, "")
    const correctSentenceText = currentPuzzle.correctSentence.toLowerCase().replace(/[.,!?]/g, "")

    if (userSentenceText === correctSentenceText) {
      // Correct answer
      const points = currentPuzzle.difficulty === "Easy" ? 50 : currentPuzzle.difficulty === "Medium" ? 75 : 100
      setScore((prev) => prev + points)
      setFeedback("correct")
      setPuzzlesCompleted((prev) => prev + 1)

      // Level up every 2 puzzles
      if ((puzzlesCompleted + 1) % 2 === 0) {
        setLevel((prev) => prev + 1)
      }

      setTimeout(() => {
        generatePuzzle()
        setFeedback(null)
      }, 2000)
    } else {
      setFeedback("incorrect")
      setTimeout(() => setFeedback(null), 2000)
    }
  }

  const resetSentence = () => {
    if (currentPuzzle) {
      setAvailableWords([...currentPuzzle.scrambledWords].sort(() => Math.random() - 0.5))
      setUserSentence([])
    }
  }

  // Timer effect
  useEffect(() => {
    if (!gameStarted || gameStatus !== "playing") return

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          setGameStatus("finished")
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [gameStarted, gameStatus])

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const getPerformanceRating = () => {
    if (puzzlesCompleted >= 8) return { rating: "Grammar Master", color: "text-green-600" }
    if (puzzlesCompleted >= 6) return { rating: "Sentence Expert", color: "text-blue-600" }
    if (puzzlesCompleted >= 4) return { rating: "Word Wizard", color: "text-purple-600" }
    if (puzzlesCompleted >= 2) return { rating: "Getting Better", color: "text-yellow-600" }
    return { rating: "Keep Practicing", color: "text-red-600" }
  }

  if (!gameStarted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-teal-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md text-center">
          <CardHeader>
            <div className="text-6xl mb-4">📝</div>
            <CardTitle className="text-2xl">Verbal Reasoning</CardTitle>
            <CardDescription>Rearrange scrambled words to form grammatically correct sentences!</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <div className="font-semibold">Time Limit</div>
                <div className="text-gray-600">2 minutes</div>
              </div>
              <div>
                <div className="font-semibold">Difficulty</div>
                <div className="text-gray-600">Progressive</div>
              </div>
              <div>
                <div className="font-semibold">Scoring</div>
                <div className="text-gray-600">50-100 per sentence</div>
              </div>
              <div>
                <div className="font-semibold">Topics</div>
                <div className="text-gray-600">Various themes</div>
              </div>
            </div>
            <Button onClick={initializeGame} className="w-full" size="lg">
              Start Game
            </Button>
            <Link href="/dashboard">
              <Button variant="outline" className="w-full">
                <Home className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (gameStatus === "finished") {
    const performance = getPerformanceRating()

    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-teal-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md text-center">
          <CardHeader>
            <div className="text-6xl mb-4">
              {performance.rating === "Grammar Master"
                ? "🏆"
                : performance.rating === "Sentence Expert"
                  ? "📚"
                  : performance.rating === "Word Wizard"
                    ? "🎭"
                    : "📝"}
            </div>
            <CardTitle className="text-2xl">Game Complete!</CardTitle>
            <CardDescription>
              You completed {puzzlesCompleted} sentences and reached level {level}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center">
              <div className="text-4xl font-bold text-green-600 mb-2">{score}</div>
              <Badge variant="secondary">Final Score</Badge>
            </div>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="text-center">
                <div className="font-semibold">Sentences</div>
                <div className="text-gray-600">{puzzlesCompleted}</div>
              </div>
              <div className="text-center">
                <div className="font-semibold">Level Reached</div>
                <div className="text-gray-600">{level}</div>
              </div>
            </div>
            <div className="text-center">
              <div className={`font-semibold ${performance.color}`}>{performance.rating}</div>
            </div>
            <div className="flex gap-2">
              <Button onClick={initializeGame} className="flex-1">
                <RotateCcw className="h-4 w-4 mr-2" />
                Play Again
              </Button>
              <Link href="/dashboard" className="flex-1">
                <Button variant="outline" className="w-full">
                  <Home className="h-4 w-4 mr-2" />
                  Dashboard
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-teal-50 p-4">
      {/* Header */}
      <div className="container mx-auto mb-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <FileText className="h-6 w-6 text-green-600" />
            <h1 className="text-2xl font-bold">Verbal Reasoning</h1>
          </div>
          <Link href="/dashboard">
            <Button variant="outline" size="sm">
              <Home className="h-4 w-4 mr-2" />
              Dashboard
            </Button>
          </Link>
        </div>

        {/* Game Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600 flex items-center justify-center gap-1">
                <Clock className="h-5 w-5" />
                {formatTime(timeLeft)}
              </div>
              <div className="text-sm text-gray-600">Time Left</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600">{score}</div>
              <div className="text-sm text-gray-600">Score</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-purple-600">{level}</div>
              <div className="text-sm text-gray-600">Level</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-orange-600">{puzzlesCompleted}</div>
              <div className="text-sm text-gray-600">Completed</div>
            </CardContent>
          </Card>
        </div>

        {/* Progress Bar */}
        <div className="mb-6">
          <Progress value={((120 - timeLeft) / 120) * 100} className="h-3" />
        </div>
      </div>

      {/* Game Area */}
      <div className="container mx-auto max-w-4xl">
        {currentPuzzle && (
          <div className="space-y-6">
            {/* Puzzle Info */}
            <Card>
              <CardHeader className="text-center">
                <div className="flex items-center justify-center gap-4 mb-2">
                  <Badge variant="secondary">{currentPuzzle.topic}</Badge>
                  <Badge
                    variant={
                      currentPuzzle.difficulty === "Easy"
                        ? "secondary"
                        : currentPuzzle.difficulty === "Medium"
                          ? "default"
                          : "destructive"
                    }
                  >
                    {currentPuzzle.difficulty}
                  </Badge>
                </div>
                <CardTitle>Arrange the words to form a correct sentence</CardTitle>
                {feedback && (
                  <div
                    className={`text-lg font-semibold ${feedback === "correct" ? "text-green-600" : "text-red-600"}`}
                  >
                    {feedback === "correct" ? "✓ Perfect! Well done!" : "✗ Not quite right, try again"}
                  </div>
                )}
              </CardHeader>
            </Card>

            {/* User Sentence Area */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Your Sentence:</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="min-h-16 p-4 border-2 border-dashed border-gray-300 rounded-lg bg-gray-50 flex flex-wrap gap-2 items-center">
                  {userSentence.length === 0 ? (
                    <span className="text-gray-400 italic">Drag words here to build your sentence...</span>
                  ) : (
                    userSentence.map((word, index) => (
                      <Button
                        key={index}
                        variant="outline"
                        size="sm"
                        onClick={() => removeWordFromSentence(index)}
                        className="bg-blue-100 border-blue-300 hover:bg-blue-200"
                      >
                        {word}
                      </Button>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Available Words */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Available Words:</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {availableWords.map((word, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      onClick={() => addWordToSentence(word, index)}
                      className="bg-white hover:bg-gray-50"
                    >
                      {word}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Action Buttons */}
            <div className="flex gap-4 justify-center">
              <Button onClick={checkSentence} disabled={userSentence.length === 0} className="flex-1 max-w-xs">
                <CheckCircle className="h-4 w-4 mr-2" />
                Check Sentence
              </Button>
              <Button variant="outline" onClick={resetSentence} className="flex-1 max-w-xs">
                <RotateCcw className="h-4 w-4 mr-2" />
                Reset
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
