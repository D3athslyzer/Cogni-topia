"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Search, RotateCcw, Home, Clock, Target } from "lucide-react"
import Link from "next/link"

interface Pattern {
  sequence: string[]
  nextItem: string
  options: string[]
}

export default function PatternRecognitionGame() {
  const [currentPattern, setCurrentPattern] = useState<Pattern | null>(null)
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null)
  const [score, setScore] = useState(0)
  const [level, setLevel] = useState(1)
  const [timeLeft, setTimeLeft] = useState(90) // 1.5 minutes
  const [patternsCompleted, setPatternsCompleted] = useState(0)
  const [gameStatus, setGameStatus] = useState<"playing" | "finished">("playing")
  const [gameStarted, setGameStarted] = useState(false)
  const [feedback, setFeedback] = useState<"correct" | "incorrect" | null>(null)

  const shapes = ["🔴", "🔵", "🟡", "🟢", "🟣", "🟠", "⚫", "⚪"]
  const numbers = ["1", "2", "3", "4", "5", "6", "7", "8", "9"]
  const letters = ["A", "B", "C", "D", "E", "F", "G", "H", "I"]

  const generatePattern = (difficulty: number): Pattern => {
    const patternTypes = ["arithmetic", "geometric", "alternating", "fibonacci", "shapes"]
    const type = patternTypes[Math.floor(Math.random() * patternTypes.length)]

    let sequence: string[] = []
    let nextItem = ""
    let options: string[] = []

    switch (type) {
      case "arithmetic":
        const start = Math.floor(Math.random() * 10) + 1
        const diff = Math.floor(Math.random() * 5) + 1
        for (let i = 0; i < 4 + difficulty; i++) {
          sequence.push((start + i * diff).toString())
        }
        nextItem = (start + sequence.length * diff).toString()
        options = [
          nextItem,
          (Number.parseInt(nextItem) + diff).toString(),
          (Number.parseInt(nextItem) - diff).toString(),
          (Number.parseInt(nextItem) + diff * 2).toString(),
        ].sort(() => Math.random() - 0.5)
        break

      case "geometric":
        const base = Math.floor(Math.random() * 3) + 2
        let current = Math.floor(Math.random() * 3) + 1
        for (let i = 0; i < 3 + Math.floor(difficulty / 2); i++) {
          sequence.push(current.toString())
          current *= base
        }
        nextItem = current.toString()
        options = [
          nextItem,
          (current * base).toString(),
          (current / base).toString(),
          (current + base).toString(),
        ].sort(() => Math.random() - 0.5)
        break

      case "alternating":
        const pattern1 = shapes[Math.floor(Math.random() * shapes.length)]
        const pattern2 = shapes[Math.floor(Math.random() * shapes.length)]
        for (let i = 0; i < 5 + difficulty; i++) {
          sequence.push(i % 2 === 0 ? pattern1 : pattern2)
        }
        nextItem = sequence.length % 2 === 0 ? pattern1 : pattern2
        options = [nextItem, pattern1, pattern2, shapes[Math.floor(Math.random() * shapes.length)]]
          .filter((item, index, arr) => arr.indexOf(item) === index)
          .slice(0, 4)
        while (options.length < 4) {
          const randomShape = shapes[Math.floor(Math.random() * shapes.length)]
          if (!options.includes(randomShape)) {
            options.push(randomShape)
          }
        }
        options = options.sort(() => Math.random() - 0.5)
        break

      case "fibonacci":
        sequence = ["1", "1"]
        for (let i = 2; i < 4 + Math.floor(difficulty / 2); i++) {
          const next = Number.parseInt(sequence[i - 1]) + Number.parseInt(sequence[i - 2])
          sequence.push(next.toString())
        }
        const lastTwo = sequence.slice(-2).map((n) => Number.parseInt(n))
        nextItem = (lastTwo[0] + lastTwo[1]).toString()
        options = [
          nextItem,
          (Number.parseInt(nextItem) + 1).toString(),
          (Number.parseInt(nextItem) - 1).toString(),
          (Number.parseInt(nextItem) * 2).toString(),
        ].sort(() => Math.random() - 0.5)
        break

      case "shapes":
        const shapePattern = []
        for (let i = 0; i < 4 + difficulty; i++) {
          shapePattern.push(shapes[i % 3])
        }
        sequence = shapePattern
        nextItem = shapes[sequence.length % 3]
        options = [nextItem, ...shapes.filter((s) => s !== nextItem).slice(0, 3)].sort(() => Math.random() - 0.5)
        break
    }

    return { sequence, nextItem, options }
  }

  const initializeGame = () => {
    setCurrentPattern(generatePattern(1))
    setSelectedAnswer(null)
    setScore(0)
    setLevel(1)
    setTimeLeft(90)
    setPatternsCompleted(0)
    setGameStatus("playing")
    setGameStarted(true)
    setFeedback(null)
  }

  const handleAnswerSelect = (answer: string) => {
    if (feedback !== null) return

    setSelectedAnswer(answer)

    const isCorrect = answer === currentPattern?.nextItem

    if (isCorrect) {
      setScore((prev) => prev + 50 * level)
      setFeedback("correct")

      // Level up every 3 correct answers
      if ((patternsCompleted + 1) % 3 === 0) {
        setLevel((prev) => prev + 1)
      }
    } else {
      setFeedback("incorrect")
    }

    setPatternsCompleted((prev) => prev + 1)

    // Show feedback briefly then move to next pattern
    setTimeout(() => {
      setCurrentPattern(generatePattern(level))
      setSelectedAnswer(null)
      setFeedback(null)
    }, 1500)
  }

  // Timer effect
  useEffect(() => {
    if (!gameStarted || gameStatus !== "playing") return

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          setGameStatus("finished")
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [gameStarted, gameStatus])

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const getPerformanceRating = () => {
    const accuracy = patternsCompleted > 0 ? (score / (patternsCompleted * 50)) * 100 : 0
    if (accuracy >= 90) return { rating: "Pattern Master", color: "text-green-600" }
    if (accuracy >= 75) return { rating: "Good Detective", color: "text-blue-600" }
    if (accuracy >= 60) return { rating: "Getting There", color: "text-yellow-600" }
    return { rating: "Keep Practicing", color: "text-red-600" }
  }

  if (!gameStarted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md text-center">
          <CardHeader>
            <div className="text-6xl mb-4">🔍</div>
            <CardTitle className="text-2xl">Pattern Recognition</CardTitle>
            <CardDescription>Identify the pattern and select the next item in the sequence!</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <div className="font-semibold">Time Limit</div>
                <div className="text-gray-600">90 seconds</div>
              </div>
              <div>
                <div className="font-semibold">Pattern Types</div>
                <div className="text-gray-600">Numbers, Shapes</div>
              </div>
              <div>
                <div className="font-semibold">Scoring</div>
                <div className="text-gray-600">50 × level</div>
              </div>
              <div>
                <div className="font-semibold">Difficulty</div>
                <div className="text-gray-600">Increases with level</div>
              </div>
            </div>
            <Button onClick={initializeGame} className="w-full" size="lg">
              Start Game
            </Button>
            <Link href="/dashboard">
              <Button variant="outline" className="w-full">
                <Home className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (gameStatus === "finished") {
    const performance = getPerformanceRating()

    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md text-center">
          <CardHeader>
            <div className="text-6xl mb-4">
              {performance.rating === "Pattern Master"
                ? "🏆"
                : performance.rating === "Good Detective"
                  ? "🕵️"
                  : performance.rating === "Getting There"
                    ? "👍"
                    : "🔍"}
            </div>
            <CardTitle className="text-2xl">Game Complete!</CardTitle>
            <CardDescription>
              You solved {patternsCompleted} patterns and reached level {level}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center">
              <div className="text-4xl font-bold text-indigo-600 mb-2">{score}</div>
              <Badge variant="secondary">Final Score</Badge>
            </div>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="text-center">
                <div className="font-semibold">Patterns</div>
                <div className="text-gray-600">{patternsCompleted}</div>
              </div>
              <div className="text-center">
                <div className="font-semibold">Level Reached</div>
                <div className="text-gray-600">{level}</div>
              </div>
            </div>
            <div className="text-center">
              <div className={`font-semibold ${performance.color}`}>{performance.rating}</div>
            </div>
            <div className="flex gap-2">
              <Button onClick={initializeGame} className="flex-1">
                <RotateCcw className="h-4 w-4 mr-2" />
                Play Again
              </Button>
              <Link href="/dashboard" className="flex-1">
                <Button variant="outline" className="w-full">
                  <Home className="h-4 w-4 mr-2" />
                  Dashboard
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-50 p-4">
      {/* Header */}
      <div className="container mx-auto mb-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Search className="h-6 w-6 text-indigo-600" />
            <h1 className="text-2xl font-bold">Pattern Recognition</h1>
          </div>
          <Link href="/dashboard">
            <Button variant="outline" size="sm">
              <Home className="h-4 w-4 mr-2" />
              Dashboard
            </Button>
          </Link>
        </div>

        {/* Game Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600 flex items-center justify-center gap-1">
                <Clock className="h-5 w-5" />
                {formatTime(timeLeft)}
              </div>
              <div className="text-sm text-gray-600">Time Left</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-indigo-600">{score}</div>
              <div className="text-sm text-gray-600">Score</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-purple-600">{level}</div>
              <div className="text-sm text-gray-600">Level</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600">{patternsCompleted}</div>
              <div className="text-sm text-gray-600">Completed</div>
            </CardContent>
          </Card>
        </div>

        {/* Progress Bar */}
        <div className="mb-6">
          <Progress value={((90 - timeLeft) / 90) * 100} className="h-3" />
        </div>
      </div>

      {/* Game Area */}
      <div className="container mx-auto max-w-2xl">
        <Card className="mb-6">
          <CardHeader className="text-center">
            <CardTitle className="text-lg mb-4">Find the Pattern</CardTitle>
            <div className="flex items-center justify-center gap-4 text-4xl mb-4">
              {currentPattern?.sequence.map((item, index) => (
                <div
                  key={index}
                  className="w-16 h-16 flex items-center justify-center border-2 border-gray-200 rounded-lg bg-white"
                >
                  {item}
                </div>
              ))}
              <div className="w-16 h-16 flex items-center justify-center border-2 border-dashed border-gray-400 rounded-lg bg-gray-50">
                ?
              </div>
            </div>
            {feedback && (
              <div className={`text-lg font-semibold ${feedback === "correct" ? "text-green-600" : "text-red-600"}`}>
                {feedback === "correct" ? "✓ Correct! Well done!" : "✗ Not quite right"}
              </div>
            )}
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {currentPattern?.options.map((option, index) => (
                <Button
                  key={index}
                  variant={selectedAnswer === option ? "default" : "outline"}
                  className={`h-16 text-2xl ${
                    feedback === "correct" && selectedAnswer === option
                      ? "bg-green-500 hover:bg-green-600"
                      : feedback === "incorrect" && selectedAnswer === option
                        ? "bg-red-500 hover:bg-red-600"
                        : ""
                  }`}
                  onClick={() => handleAnswerSelect(option)}
                  disabled={feedback !== null}
                >
                  {option}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Level Progress */}
        <Card className="bg-gradient-to-r from-indigo-100 to-purple-100 border-indigo-300">
          <CardContent className="p-4 text-center">
            <div className="flex items-center justify-center gap-2">
              <Target className="h-5 w-5 text-indigo-600" />
              <span className="font-semibold text-indigo-800">
                Level {level} • {3 - (patternsCompleted % 3)} patterns to next level
              </span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
