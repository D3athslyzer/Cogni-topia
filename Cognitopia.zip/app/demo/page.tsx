"use client"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Brain, Play, ArrowLeft } from "lucide-react"

export default function DemoPage() {
  const demoGames = [
    {
      id: 1,
      name: "Memory Match Demo",
      description: "Try a simplified version of our memory matching game",
      icon: "🧠",
      difficulty: "Easy",
      duration: "2 min",
      href: "/games/1",
    },
    {
      id: 2,
      name: "Speed Math Demo",
      description: "Test your arithmetic skills with quick calculations",
      icon: "🔢",
      difficulty: "Medium",
      duration: "1 min",
      href: "/games/2",
    },
    {
      id: 3,
      name: "Pattern Recognition Demo",
      description: "Identify patterns and sequences in this logic game",
      icon: "🔍",
      difficulty: "Hard",
      duration: "1.5 min",
      href: "/games/3",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Brain className="h-8 w-8 text-blue-600" />
            <span className="text-2xl font-bold text-gray-900">Cognitopia</span>
          </div>
          <Link href="/">
            <Button variant="outline">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Button>
          </Link>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">Try Our Brain Training Games</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Experience the power of cognitive training with these demo games. No account required - just jump in and
            start training your brain!
          </p>
        </div>

        {/* Demo Games Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {demoGames.map((game) => (
            <Card key={game.id} className="hover:shadow-lg transition-all duration-300 group">
              <CardHeader className="text-center">
                <div className="text-6xl mb-4 group-hover:scale-110 transition-transform">{game.icon}</div>
                <CardTitle className="text-xl">{game.name}</CardTitle>
                <CardDescription className="text-base">{game.description}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Difficulty:</span>
                  <span
                    className={`font-medium ${
                      game.difficulty === "Easy"
                        ? "text-green-600"
                        : game.difficulty === "Medium"
                          ? "text-yellow-600"
                          : "text-red-600"
                    }`}
                  >
                    {game.difficulty}
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Duration:</span>
                  <span className="font-medium">{game.duration}</span>
                </div>
                <Link href={game.href} className="block">
                  <Button className="w-full" size="lg">
                    <Play className="h-4 w-4 mr-2" />
                    Play Demo
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16">
          <Card className="max-w-2xl mx-auto bg-gradient-to-r from-blue-500 to-indigo-600 text-white border-0">
            <CardContent className="p-8">
              <h2 className="text-2xl font-bold mb-4">Ready for More?</h2>
              <p className="text-blue-100 mb-6">
                Unlock the full potential of your brain with our complete training program. Get access to 15+ games,
                detailed progress tracking, and personalized training plans.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link href="/signup">
                  <Button size="lg" variant="secondary" className="text-blue-600">
                    Start Free Trial
                  </Button>
                </Link>
                <Link href="/login">
                  <Button
                    size="lg"
                    variant="outline"
                    className="border-white text-white hover:bg-white hover:text-blue-600"
                  >
                    Sign In
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
