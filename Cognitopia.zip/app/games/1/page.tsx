"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Brain, RotateCcw, Home } from "lucide-react"
import Link from "next/link"

interface MemoryCard {
  id: number
  value: string
  isFlipped: boolean
  isMatched: boolean
}

export default function MemoryMatchGame() {
  const [cards, setCards] = useState<MemoryCard[]>([])
  const [flippedCards, setFlippedCards] = useState<number[]>([])
  const [matches, setMatches] = useState(0)
  const [moves, setMoves] = useState(0)
  const [score, setScore] = useState(0)
  const [timeLeft, setTimeLeft] = useState(120) // 2 minutes
  const [gameStatus, setGameStatus] = useState<"playing" | "won" | "lost">("playing")
  const [gameStarted, setGameStarted] = useState(false)

  const cardValues = ["🎯", "🧠", "⚡", "🔥", "🎮", "🏆", "⭐", "💎"]

  const initializeGame = () => {
    const shuffledCards = [...cardValues, ...cardValues]
      .sort(() => Math.random() - 0.5)
      .map((value, index) => ({
        id: index,
        value,
        isFlipped: false,
        isMatched: false,
      }))

    setCards(shuffledCards)
    setFlippedCards([])
    setMatches(0)
    setMoves(0)
    setScore(0)
    setTimeLeft(120)
    setGameStatus("playing")
    setGameStarted(true)
  }

  const handleCardClick = (cardId: number) => {
    if (gameStatus !== "playing" || flippedCards.length === 2) return

    const card = cards.find((c) => c.id === cardId)
    if (!card || card.isFlipped || card.isMatched) return

    const newFlippedCards = [...flippedCards, cardId]
    setFlippedCards(newFlippedCards)

    setCards((prev) => prev.map((c) => (c.id === cardId ? { ...c, isFlipped: true } : c)))

    if (newFlippedCards.length === 2) {
      setMoves((prev) => prev + 1)

      const [firstId, secondId] = newFlippedCards
      const firstCard = cards.find((c) => c.id === firstId)
      const secondCard = cards.find((c) => c.id === secondId)

      if (firstCard?.value === secondCard?.value) {
        // Match found
        setTimeout(() => {
          setCards((prev) => prev.map((c) => (c.id === firstId || c.id === secondId ? { ...c, isMatched: true } : c)))
          setMatches((prev) => prev + 1)
          setScore((prev) => prev + 100)
          setFlippedCards([])
        }, 1000)
      } else {
        // No match
        setTimeout(() => {
          setCards((prev) => prev.map((c) => (c.id === firstId || c.id === secondId ? { ...c, isFlipped: false } : c)))
          setFlippedCards([])
        }, 1000)
      }
    }
  }

  // Timer effect
  useEffect(() => {
    if (!gameStarted || gameStatus !== "playing") return

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          setGameStatus("lost")
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [gameStarted, gameStatus])

  // Check win condition
  useEffect(() => {
    if (matches === cardValues.length && gameStatus === "playing") {
      setGameStatus("won")
      const timeBonus = timeLeft * 5
      setScore((prev) => prev + timeBonus)
    }
  }, [matches, cardValues.length, gameStatus, timeLeft])

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  if (!gameStarted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md text-center">
          <CardHeader>
            <div className="text-6xl mb-4">🧠</div>
            <CardTitle className="text-2xl">Memory Match</CardTitle>
            <CardDescription>Find matching pairs of cards. Complete all matches before time runs out!</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <div className="font-semibold">Time Limit</div>
                <div className="text-gray-600">2 minutes</div>
              </div>
              <div>
                <div className="font-semibold">Cards</div>
                <div className="text-gray-600">16 cards</div>
              </div>
              <div>
                <div className="font-semibold">Matches</div>
                <div className="text-gray-600">8 pairs</div>
              </div>
              <div>
                <div className="font-semibold">Scoring</div>
                <div className="text-gray-600">100 per match</div>
              </div>
            </div>
            <Button onClick={initializeGame} className="w-full" size="lg">
              Start Game
            </Button>
            <Link href="/dashboard">
              <Button variant="outline" className="w-full">
                <Home className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50 p-4">
      {/* Header */}
      <div className="container mx-auto mb-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Brain className="h-6 w-6 text-purple-600" />
            <h1 className="text-2xl font-bold">Memory Match</h1>
          </div>
          <Link href="/dashboard">
            <Button variant="outline" size="sm">
              <Home className="h-4 w-4 mr-2" />
              Dashboard
            </Button>
          </Link>
        </div>

        {/* Game Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600">{formatTime(timeLeft)}</div>
              <div className="text-sm text-gray-600">Time Left</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600">{score}</div>
              <div className="text-sm text-gray-600">Score</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-purple-600">{matches}/8</div>
              <div className="text-sm text-gray-600">Matches</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-orange-600">{moves}</div>
              <div className="text-sm text-gray-600">Moves</div>
            </CardContent>
          </Card>
        </div>

        {/* Progress Bar */}
        <div className="mb-6">
          <Progress value={(matches / cardValues.length) * 100} className="h-3" />
        </div>
      </div>

      {/* Game Board */}
      <div className="container mx-auto max-w-2xl">
        <div className="grid grid-cols-4 gap-4 mb-6">
          {cards.map((card) => (
            <Card
              key={card.id}
              className={`aspect-square cursor-pointer transition-all duration-300 ${
                card.isFlipped || card.isMatched
                  ? "bg-white shadow-lg"
                  : "bg-gradient-to-br from-purple-400 to-blue-500 hover:shadow-lg"
              } ${card.isMatched ? "ring-2 ring-green-400" : ""}`}
              onClick={() => handleCardClick(card.id)}
            >
              <CardContent className="p-0 h-full flex items-center justify-center">
                {card.isFlipped || card.isMatched ? (
                  <div className="text-4xl">{card.value}</div>
                ) : (
                  <div className="text-white text-2xl">?</div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Game Over Modal */}
        {gameStatus !== "playing" && (
          <Card className="max-w-md mx-auto">
            <CardHeader className="text-center">
              <div className="text-6xl mb-4">{gameStatus === "won" ? "🏆" : "😔"}</div>
              <CardTitle className="text-2xl">{gameStatus === "won" ? "Congratulations!" : "Game Over"}</CardTitle>
              <CardDescription>
                {gameStatus === "won"
                  ? `You completed all matches with ${moves} moves!`
                  : "Time ran out! Try again to improve your score."}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600 mb-2">{score}</div>
                <Badge variant="secondary">Final Score</Badge>
              </div>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="text-center">
                  <div className="font-semibold">Matches</div>
                  <div className="text-gray-600">{matches}/8</div>
                </div>
                <div className="text-center">
                  <div className="font-semibold">Moves</div>
                  <div className="text-gray-600">{moves}</div>
                </div>
              </div>
              <div className="flex gap-2">
                <Button onClick={initializeGame} className="flex-1">
                  <RotateCcw className="h-4 w-4 mr-2" />
                  Play Again
                </Button>
                <Link href="/dashboard" className="flex-1">
                  <Button variant="outline" className="w-full">
                    <Home className="h-4 w-4 mr-2" />
                    Dashboard
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
