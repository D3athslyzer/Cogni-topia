"use client"

import { useState } from "react"

interface WordChallenge {
  letters: string
  minWords: number
  targetWord: string
  category: string
}

export default function WordBuilderGame() {
  const [currentChallenge, setCurrentChallenge] = useState<WordChallenge | null>(null)
  const [userWord, setUserWord] = useState("")
  const [foundWords, setFoundWords] = useState<string[]>([])
  const [score, setScore] = useState(0)
  const [level, setLevel] = useState(1)
  const [timeLeft, setTimeLeft] = useState(180) // 3 minutes
  const [gameStatus, setGameStatus] = useState<"playing" | "finished">("playing")
  const [gameStarted, setGameStarted] = useState(false)
  const [feedback, setFeedback] = useState<string | null>(null)

  const wordChallenges: WordChallenge[] = [
    {
      letters: "CREATION",
      minWords: 8,
      targetWord: "CREATION",
      category: "Art & Design"
    },
    {
      letters: "EDUCATION",
      minWords: 10,
      targetWord: "EDUCATION",
      category: "Learning"
    },
    {
      letters: "TECHNOLOGY",
      minWords: 12,
      targetWord: "TECHNOLOGY",
      category: "Science"
    },
    {
      letters: "ADVENTURE",
      minWords: 9,
      targetWord: "ADVENTURE",
      category: "Travel"
    },
    {
      letters: "FRIENDSHIP",
      minWords: 11,
      targetWord: "FRIENDSHIP",
      category: "Relationships"
    }
  ]

  // Valid words that can be formed from each set of letters
  const validWords: { [key: string]: string[] } = {
    "CREATION": ["CREATE", "REACT", "TRACE", "CARE", "RACE", "RATE", "TEAR", "NEAR", "CART", "ART", "CAR", "CAT", "RAT", "EAR", "EAT", "TEA", "TEN", "NET", "TON", "NOT", "COT", "ROT", "ORE", "TOE", "ACE", "ICE"],
    "EDUCATION": ["EDUCATE", "CAUTION", "ACTION", "NATION", "DANCE", "OCEAN", "CANOE", "ACUTE", "AUDIO", "UNITE", "UNTIE", "NOTED", "TUNED", "DUNE", "NUDE", "TONE", "NOTE", "DATE", "IDEA", "AIDE", "DICE", "NICE", "ONCE", "CONE", "DONE", "NODE", "CODE", "UNDO", "AUNT", "TUNA", "AUTO"],
    "TECHNOLOGY": ["ECOLOGY", "COLLEGE", "TOGGLE", "GENTLE", "LENGTH", "GOLDEN", "LONELY", "COLONY", "HONEY", "MONEY", "GHOST", "HOTEL", "CLOTH", "YOUTH", "MONTH", "NORTH", "TOOTH", "COOL", "TOOL", "LONG", "GONE", "TONE", "NOTE", "HOLE", "GOAL", "COAL", "COAT", "GOAT", "HEAT", "NEAT", "LEAN", "CLEAN"],
    "ADVENTURE\": ["\
