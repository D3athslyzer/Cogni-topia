"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Brain, Trophy, Target, TrendingUp, Play, Star, Calendar, User } from "lucide-react"

export default function DashboardPage() {
  const [user] = useState({
    name: "Alex Johnson",
    level: 12,
    xp: 2450,
    streak: 7,
    gamesPlayed: 156,
  })

  const games = [
    {
      id: 1,
      name: "Memory Match",
      description: "Test your memory with card matching",
      difficulty: "Medium",
      bestScore: 1250,
      icon: "🧠",
      category: "Memory",
    },
    {
      id: 2,
      name: "Speed Math",
      description: "Quick arithmetic challenges",
      difficulty: "Easy",
      bestScore: 890,
      icon: "🔢",
      category: "Processing Speed",
    },
    {
      id: 3,
      name: "Pattern Recognition",
      description: "Identify sequences and patterns",
      difficulty: "Hard",
      bestScore: 2100,
      icon: "🔍",
      category: "Problem Solving",
    },
    {
      id: 4,
      name: "Jargon Jam",
      description: "Rapid-fire business vocabulary",
      difficulty: "Medium",
      bestScore: 1680,
      icon: "💼",
      category: "Vocabulary",
    },
    {
      id: 5,
      name: "Commerce Crossword",
      description: "Business knowledge puzzles",
      difficulty: "Hard",
      bestScore: 1950,
      icon: "📊",
      category: "Knowledge",
    },
    {
      id: 6,
      name: "Verbal Reasoning",
      description: "Sentence structure challenges",
      difficulty: "Medium",
      bestScore: 1420,
      icon: "📝",
      category: "Language",
    },
    {
      id: 7,
      name: "Word Builder",
      description: "Vocabulary and language skills",
      difficulty: "Easy",
      bestScore: 980,
      icon: "🔤",
      category: "Language",
    },
    {
      id: 8,
      name: "Attention Focus",
      description: "Concentration training",
      difficulty: "Medium",
      bestScore: 1340,
      icon: "🎯",
      category: "Attention",
    },
    {
      id: 9,
      name: "Logic Puzzles",
      description: "Problem solving challenges",
      difficulty: "Hard",
      bestScore: 2250,
      icon: "🧩",
      category: "Logic",
    },
  ]

  const recentActivity = [
    { game: "Memory Match", score: 1180, date: "Today", improvement: "+12%" },
    { game: "Speed Math", score: 920, date: "Yesterday", improvement: "+8%" },
    { game: "Pattern Recognition", score: 2050, date: "2 days ago", improvement: "+15%" },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Brain className="h-8 w-8 text-blue-600" />
            <span className="text-2xl font-bold text-gray-900">Cognitopia</span>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm">
              <User className="h-4 w-4 mr-2" />
              Profile
            </Button>
            <Button variant="ghost" size="sm">
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Welcome back, {user.name}! 👋</h1>
          <p className="text-gray-600">Ready to boost your brain power today?</p>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Level</CardTitle>
              <Trophy className="h-4 w-4 text-yellow-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{user.level}</div>
              <Progress value={65} className="mt-2" />
              <p className="text-xs text-muted-foreground mt-1">{user.xp}/3000 XP to next level</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Streak</CardTitle>
              <Target className="h-4 w-4 text-orange-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{user.streak} days</div>
              <p className="text-xs text-muted-foreground">Keep it up! 🔥</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Games Played</CardTitle>
              <Play className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{user.gamesPlayed}</div>
              <p className="text-xs text-muted-foreground">This month: +23</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Avg Score</CardTitle>
              <TrendingUp className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">1,425</div>
              <p className="text-xs text-muted-foreground">+12% from last week</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Games Grid */}
          <div className="lg:col-span-2">
            <h2 className="text-2xl font-bold mb-6">Brain Training Games</h2>
            <div className="grid md:grid-cols-2 gap-6">
              {games.map((game) => (
                <Card key={game.id} className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="text-3xl">{game.icon}</div>
                        <div>
                          <CardTitle className="text-lg">{game.name}</CardTitle>
                          <CardDescription>{game.category}</CardDescription>
                        </div>
                      </div>
                      <Badge
                        variant={
                          game.difficulty === "Easy"
                            ? "secondary"
                            : game.difficulty === "Medium"
                              ? "default"
                              : "destructive"
                        }
                      >
                        {game.difficulty}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">{game.description}</p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1">
                        <Star className="h-4 w-4 text-yellow-500" />
                        <span className="text-sm font-medium">Best: {game.bestScore}</span>
                      </div>
                      <Link href={`/games/${game.id}`}>
                        <Button size="sm">
                          <Play className="h-4 w-4 mr-1" />
                          Play
                        </Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  Recent Activity
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {recentActivity.map((activity, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-sm">{activity.game}</p>
                      <p className="text-xs text-gray-500">{activity.date}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-sm">{activity.score}</p>
                      <p className="text-xs text-green-600">{activity.improvement}</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Daily Challenge */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Trophy className="h-5 w-5 text-yellow-600" />
                  Daily Challenge
                </CardTitle>
                <CardDescription>Complete today's challenge for bonus XP!</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-4">
                  <div className="text-4xl mb-2">🎯</div>
                  <h3 className="font-semibold mb-2">Focus Master</h3>
                  <p className="text-sm text-gray-600 mb-4">Score 1000+ in Attention Focus</p>
                  <Button className="w-full">Start Challenge</Button>
                </div>
              </CardContent>
            </Card>

            {/* Achievements */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Trophy className="h-5 w-5 text-yellow-600" />
                  Recent Achievements
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="text-2xl">🏆</div>
                  <div>
                    <p className="font-medium text-sm">Memory Master</p>
                    <p className="text-xs text-gray-500">Score 1000+ in Memory Match</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-2xl">🔥</div>
                  <div>
                    <p className="font-medium text-sm">Week Warrior</p>
                    <p className="text-xs text-gray-500">7-day training streak</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-2xl">⚡</div>
                  <div>
                    <p className="font-medium text-sm">Speed Demon</p>
                    <p className="text-xs text-gray-500">Complete 10 Speed Math games</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
