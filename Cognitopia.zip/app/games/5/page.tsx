"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { BarChart3, RotateCcw, Home, Clock, Lightbulb } from "lucide-react"
import Link from "next/link"

interface CrosswordClue {
  id: number
  clue: string
  answer: string
  direction: "across" | "down"
  startRow: number
  startCol: number
  length: number
}

interface CrosswordCell {
  letter: string
  isBlack: boolean
  number?: number
  userLetter?: string
}

export default function CommerceCrosswordGame() {
  const [grid, setGrid] = useState<CrosswordCell[][]>([])
  const [clues, setClues] = useState<CrosswordClue[]>([])
  const [selectedClue, setSelectedClue] = useState<CrosswordClue | null>(null)
  const [currentAnswer, setCurrentAnswer] = useState("")
  const [score, setScore] = useState(0)
  const [completedClues, setCompletedClues] = useState<number[]>([])
  const [timeLeft, setTimeLeft] = useState(300) // 5 minutes
  const [gameStatus, setGameStatus] = useState<"playing" | "finished">("playing")
  const [gameStarted, setGameStarted] = useState(false)
  const [hint, setHint] = useState<string | null>(null)

  const crosswordData: CrosswordClue[] = [
    {
      id: 1,
      clue: "Online marketplace founded by Jeff Bezos",
      answer: "AMAZON",
      direction: "across",
      startRow: 1,
      startCol: 1,
      length: 6,
    },
    {
      id: 2,
      clue: "Currency of the European Union",
      answer: "EURO",
      direction: "down",
      startRow: 1,
      startCol: 3,
      length: 4,
    },
    {
      id: 3,
      clue: "Famous economist who wrote 'The Wealth of Nations'",
      answer: "SMITH",
      direction: "across",
      startRow: 3,
      startCol: 0,
      length: 5,
    },
    {
      id: 4,
      clue: "Business strategy of buying and selling goods",
      answer: "TRADE",
      direction: "down",
      startRow: 0,
      startCol: 4,
      length: 5,
    },
    {
      id: 5,
      clue: "Financial institution that lends money",
      answer: "BANK",
      direction: "across",
      startRow: 5,
      startCol: 2,
      length: 4,
    },
    {
      id: 6,
      clue: "Company's total income before expenses",
      answer: "REVENUE",
      direction: "across",
      startRow: 2,
      startCol: 1,
      length: 7,
    },
    {
      id: 7,
      clue: "Stock market index with 30 companies",
      answer: "DOW",
      direction: "down",
      startRow: 2,
      startCol: 6,
      length: 3,
    },
    {
      id: 8,
      clue: "Economic system based on private ownership",
      answer: "CAPITALISM",
      direction: "across",
      startRow: 4,
      startCol: 0,
      length: 10,
    },
  ]

  const initializeGame = () => {
    // Create 8x12 grid
    const newGrid: CrosswordCell[][] = Array(8)
      .fill(null)
      .map(() =>
        Array(12)
          .fill(null)
          .map(() => ({ letter: "", isBlack: true })),
      )

    // Place words in grid
    crosswordData.forEach((clue) => {
      for (let i = 0; i < clue.length; i++) {
        const row = clue.direction === "across" ? clue.startRow : clue.startRow + i
        const col = clue.direction === "across" ? clue.startCol + i : clue.startCol

        if (row < 8 && col < 12) {
          newGrid[row][col] = {
            letter: clue.answer[i],
            isBlack: false,
            number: i === 0 ? clue.id : undefined,
            userLetter: "",
          }
        }
      }
    })

    setGrid(newGrid)
    setClues(crosswordData)
    setSelectedClue(null)
    setCurrentAnswer("")
    setScore(0)
    setCompletedClues([])
    setTimeLeft(300)
    setGameStatus("playing")
    setGameStarted(true)
    setHint(null)
  }

  const handleClueSelect = (clue: CrosswordClue) => {
    setSelectedClue(clue)
    setCurrentAnswer("")
    setHint(null)
  }

  const handleSubmitAnswer = (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedClue || !currentAnswer.trim()) return

    const answer = currentAnswer.trim().toUpperCase()

    if (answer === selectedClue.answer) {
      // Correct answer
      setScore((prev) => prev + selectedClue.length * 10)
      setCompletedClues((prev) => [...prev, selectedClue.id])

      // Update grid with user's answer
      const newGrid = [...grid]
      for (let i = 0; i < selectedClue.length; i++) {
        const row = selectedClue.direction === "across" ? selectedClue.startRow : selectedClue.startRow + i
        const col = selectedClue.direction === "across" ? selectedClue.startCol + i : selectedClue.startCol

        if (row < 8 && col < 12) {
          newGrid[row][col] = {
            ...newGrid[row][col],
            userLetter: selectedClue.answer[i],
          }
        }
      }
      setGrid(newGrid)

      setCurrentAnswer("")
      setSelectedClue(null)

      // Check if game is complete
      if (completedClues.length + 1 === clues.length) {
        setGameStatus("finished")
      }
    } else {
      setHint("❌ Incorrect answer. Try again!")
      setTimeout(() => setHint(null), 2000)
    }
  }

  const getHint = () => {
    if (!selectedClue) return

    const answer = selectedClue.answer
    const hintLetter = answer[Math.floor(Math.random() * answer.length)]
    setHint(`💡 Hint: The word contains the letter "${hintLetter}"`)
    setTimeout(() => setHint(null), 5000)
  }

  // Timer effect
  useEffect(() => {
    if (!gameStarted || gameStatus !== "playing") return

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          setGameStatus("finished")
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [gameStarted, gameStatus])

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  if (!gameStarted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md text-center">
          <CardHeader>
            <div className="text-6xl mb-4">📊</div>
            <CardTitle className="text-2xl">Commerce Crossword Combat</CardTitle>
            <CardDescription>
              Solve business and economics crossword clues using your commerce knowledge!
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <div className="font-semibold">Time Limit</div>
                <div className="text-gray-600">5 minutes</div>
              </div>
              <div>
                <div className="font-semibold">Clues</div>
                <div className="text-gray-600">8 commerce terms</div>
              </div>
              <div>
                <div className="font-semibold">Scoring</div>
                <div className="text-gray-600">10 per letter</div>
              </div>
              <div>
                <div className="font-semibold">Topics</div>
                <div className="text-gray-600">Business, Economics</div>
              </div>
            </div>
            <Button onClick={initializeGame} className="w-full" size="lg">
              Start Crossword
            </Button>
            <Link href="/dashboard">
              <Button variant="outline" className="w-full">
                <Home className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (gameStatus === "finished") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md text-center">
          <CardHeader>
            <div className="text-6xl mb-4">{completedClues.length === clues.length ? "🏆" : "⏰"}</div>
            <CardTitle className="text-2xl">
              {completedClues.length === clues.length ? "Perfect Score!" : "Time's Up!"}
            </CardTitle>
            <CardDescription>
              You completed {completedClues.length} out of {clues.length} clues
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center">
              <div className="text-4xl font-bold text-blue-600 mb-2">{score}</div>
              <Badge variant="secondary">Final Score</Badge>
            </div>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="text-center">
                <div className="font-semibold">Completed</div>
                <div className="text-gray-600">
                  {completedClues.length}/{clues.length}
                </div>
              </div>
              <div className="text-center">
                <div className="font-semibold">Accuracy</div>
                <div className="text-gray-600">{Math.round((completedClues.length / clues.length) * 100)}%</div>
              </div>
            </div>
            <div className="flex gap-2">
              <Button onClick={initializeGame} className="flex-1">
                <RotateCcw className="h-4 w-4 mr-2" />
                Play Again
              </Button>
              <Link href="/dashboard" className="flex-1">
                <Button variant="outline" className="w-full">
                  <Home className="h-4 w-4 mr-2" />
                  Dashboard
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50 p-4">
      {/* Header */}
      <div className="container mx-auto mb-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <BarChart3 className="h-6 w-6 text-blue-600" />
            <h1 className="text-2xl font-bold">Commerce Crossword Combat</h1>
          </div>
          <Link href="/dashboard">
            <Button variant="outline" size="sm">
              <Home className="h-4 w-4 mr-2" />
              Dashboard
            </Button>
          </Link>
        </div>

        {/* Game Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600 flex items-center justify-center gap-1">
                <Clock className="h-5 w-5" />
                {formatTime(timeLeft)}
              </div>
              <div className="text-sm text-gray-600">Time Left</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600">{score}</div>
              <div className="text-sm text-gray-600">Score</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-purple-600">
                {completedClues.length}/{clues.length}
              </div>
              <div className="text-sm text-gray-600">Completed</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-orange-600">
                {Math.round((completedClues.length / clues.length) * 100)}%
              </div>
              <div className="text-sm text-gray-600">Progress</div>
            </CardContent>
          </Card>
        </div>

        {/* Progress Bar */}
        <div className="mb-6">
          <Progress value={(completedClues.length / clues.length) * 100} className="h-3" />
        </div>
      </div>

      <div className="container mx-auto max-w-6xl grid lg:grid-cols-2 gap-8">
        {/* Crossword Grid */}
        <Card>
          <CardHeader>
            <CardTitle>Crossword Grid</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-12 gap-1 max-w-md mx-auto">
              {grid.map((row, rowIndex) =>
                row.map((cell, colIndex) => (
                  <div
                    key={`${rowIndex}-${colIndex}`}
                    className={`aspect-square text-xs flex items-center justify-center border relative ${
                      cell.isBlack
                        ? "bg-black"
                        : cell.userLetter
                          ? "bg-green-100 border-green-300"
                          : "bg-white border-gray-300"
                    }`}
                  >
                    {cell.number && (
                      <div className="absolute top-0 left-0 text-xs font-bold text-blue-600">{cell.number}</div>
                    )}
                    {!cell.isBlack && <span className="font-bold">{cell.userLetter || ""}</span>}
                  </div>
                )),
              )}
            </div>
          </CardContent>
        </Card>

        {/* Clues and Answer Input */}
        <div className="space-y-6">
          {/* Clues */}
          <Card>
            <CardHeader>
              <CardTitle>Clues</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 max-h-64 overflow-y-auto">
              {clues.map((clue) => (
                <div
                  key={clue.id}
                  className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                    completedClues.includes(clue.id)
                      ? "bg-green-50 border-green-200 text-green-800"
                      : selectedClue?.id === clue.id
                        ? "bg-blue-50 border-blue-200"
                        : "bg-gray-50 border-gray-200 hover:bg-gray-100"
                  }`}
                  onClick={() => !completedClues.includes(clue.id) && handleClueSelect(clue)}
                >
                  <div className="flex items-start gap-2">
                    <Badge variant="outline" className="text-xs">
                      {clue.id} {clue.direction}
                    </Badge>
                    <div className="flex-1">
                      <p className="text-sm">{clue.clue}</p>
                      <p className="text-xs text-gray-500 mt-1">{clue.length} letters</p>
                    </div>
                    {completedClues.includes(clue.id) && <span className="text-green-600">✓</span>}
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Answer Input */}
          {selectedClue && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">
                  {selectedClue.id} {selectedClue.direction}: {selectedClue.clue}
                </CardTitle>
                <CardDescription>{selectedClue.length} letters</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <form onSubmit={handleSubmitAnswer} className="space-y-4">
                  <Input
                    value={currentAnswer}
                    onChange={(e) => setCurrentAnswer(e.target.value.toUpperCase())}
                    placeholder="Enter your answer..."
                    className="text-lg"
                    maxLength={selectedClue.length}
                    autoFocus
                  />
                  <div className="flex gap-2">
                    <Button type="submit" className="flex-1" disabled={!currentAnswer.trim()}>
                      Submit Answer
                    </Button>
                    <Button type="button" variant="outline" onClick={getHint}>
                      <Lightbulb className="h-4 w-4 mr-2" />
                      Hint
                    </Button>
                  </div>
                </form>
                {hint && <div className="text-sm p-2 bg-yellow-50 border border-yellow-200 rounded">{hint}</div>}
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
