"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Briefcase, RotateCcw, Home, Clock, Target } from "lucide-react"
import Link from "next/link"

interface BusinessWord {
  word: string
  category: string
  relatedWords: string[]
}

export default function JargonJamGame() {
  const [currentWord, setCurrentWord] = useState<BusinessWord | null>(null)
  const [userAnswers, setUserAnswers] = useState<string[]>([])
  const [currentAnswer, setCurrentAnswer] = useState("")
  const [score, setScore] = useState(0)
  const [round, setRound] = useState(1)
  const [timeLeft, setTimeLeft] = useState(30)
  const [gameStatus, setGameStatus] = useState<"playing" | "finished">("playing")
  const [gameStarted, setGameStarted] = useState(false)
  const [feedback, setFeedback] = useState<string | null>(null)
  const [roundScore, setRoundScore] = useState(0)

  const businessWords: BusinessWord[] = [
    {
      word: "MARKETING",
      category: "Business Strategy",
      relatedWords: [
        "advertising",
        "promotion",
        "branding",
        "campaign",
        "target",
        "audience",
        "digital",
        "social",
        "content",
        "strategy",
      ],
    },
    {
      word: "FINANCE",
      category: "Money Management",
      relatedWords: [
        "budget",
        "investment",
        "profit",
        "revenue",
        "accounting",
        "banking",
        "loan",
        "credit",
        "capital",
        "assets",
      ],
    },
    {
      word: "LEADERSHIP",
      category: "Management",
      relatedWords: [
        "management",
        "team",
        "vision",
        "strategy",
        "motivation",
        "delegation",
        "communication",
        "decision",
        "guidance",
        "influence",
      ],
    },
    {
      word: "INNOVATION",
      category: "Development",
      relatedWords: [
        "creativity",
        "technology",
        "development",
        "research",
        "breakthrough",
        "invention",
        "improvement",
        "disruption",
        "solution",
        "progress",
      ],
    },
    {
      word: "NETWORKING",
      category: "Professional Relations",
      relatedWords: [
        "connections",
        "relationships",
        "contacts",
        "professional",
        "collaboration",
        "partnership",
        "communication",
        "referrals",
        "community",
        "events",
      ],
    },
    {
      word: "STRATEGY",
      category: "Planning",
      relatedWords: [
        "planning",
        "goals",
        "objectives",
        "tactics",
        "approach",
        "vision",
        "execution",
        "competitive",
        "analysis",
        "framework",
      ],
    },
    {
      word: "PRODUCTIVITY",
      category: "Efficiency",
      relatedWords: [
        "efficiency",
        "performance",
        "output",
        "workflow",
        "optimization",
        "time",
        "management",
        "results",
        "effectiveness",
        "automation",
      ],
    },
    {
      word: "ENTREPRENEURSHIP",
      category: "Business Creation",
      relatedWords: [
        "startup",
        "business",
        "venture",
        "innovation",
        "risk",
        "opportunity",
        "founder",
        "investment",
        "growth",
        "vision",
      ],
    },
  ]

  const initializeGame = () => {
    setCurrentWord(businessWords[Math.floor(Math.random() * businessWords.length)])
    setUserAnswers([])
    setCurrentAnswer("")
    setScore(0)
    setRound(1)
    setTimeLeft(30)
    setGameStatus("playing")
    setGameStarted(true)
    setFeedback(null)
    setRoundScore(0)
  }

  const handleSubmitAnswer = (e: React.FormEvent) => {
    e.preventDefault()
    if (!currentAnswer.trim() || userAnswers.length >= 5) return

    const answer = currentAnswer.trim().toLowerCase()
    const mainWord = currentWord?.word.toLowerCase()

    // Check if answer contains the main word
    if (mainWord && answer.includes(mainWord)) {
      setFeedback("❌ Cannot use the main word!")
      setTimeout(() => setFeedback(null), 1500)
      return
    }

    // Check if already used
    if (userAnswers.some((a) => a.toLowerCase() === answer)) {
      setFeedback("❌ Already used!")
      setTimeout(() => setFeedback(null), 1500)
      return
    }

    // Check if it's a valid related word
    const isValid = currentWord?.relatedWords.some(
      (word) => word.toLowerCase().includes(answer) || answer.includes(word.toLowerCase()),
    )

    const newAnswers = [...userAnswers, currentAnswer.trim()]
    setUserAnswers(newAnswers)
    setCurrentAnswer("")

    if (isValid) {
      const points = 20
      setRoundScore((prev) => prev + points)
      setFeedback(`✅ +${points} points!`)
    } else {
      setFeedback("⚠️ Not quite related")
    }

    setTimeout(() => setFeedback(null), 1500)

    // Check if round is complete
    if (newAnswers.length >= 5) {
      completeRound()
    }
  }

  const completeRound = () => {
    setScore((prev) => prev + roundScore)

    if (round < 5) {
      // Next round
      setTimeout(() => {
        setRound((prev) => prev + 1)
        setCurrentWord(businessWords[Math.floor(Math.random() * businessWords.length)])
        setUserAnswers([])
        setTimeLeft(30)
        setRoundScore(0)
        setFeedback(null)
      }, 2000)
    } else {
      // Game finished
      setGameStatus("finished")
    }
  }

  // Timer effect
  useEffect(() => {
    if (!gameStarted || gameStatus !== "playing" || userAnswers.length >= 5) return

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          completeRound()
          return 30
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [gameStarted, gameStatus, userAnswers.length, round])

  const formatTime = (seconds: number) => {
    return `0:${seconds.toString().padStart(2, "0")}`
  }

  if (!gameStarted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md text-center">
          <CardHeader>
            <div className="text-6xl mb-4">💼</div>
            <CardTitle className="text-2xl">Jargon Jam</CardTitle>
            <CardDescription>
              See a business word and quickly name 5 related terms without using the main word!
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <div className="font-semibold">Time per Round</div>
                <div className="text-gray-600">30 seconds</div>
              </div>
              <div>
                <div className="font-semibold">Rounds</div>
                <div className="text-gray-600">5 rounds</div>
              </div>
              <div>
                <div className="font-semibold">Words per Round</div>
                <div className="text-gray-600">5 related words</div>
              </div>
              <div>
                <div className="font-semibold">Scoring</div>
                <div className="text-gray-600">20 per valid word</div>
              </div>
            </div>
            <Button onClick={initializeGame} className="w-full" size="lg">
              Start Game
            </Button>
            <Link href="/dashboard">
              <Button variant="outline" className="w-full">
                <Home className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (gameStatus === "finished") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md text-center">
          <CardHeader>
            <div className="text-6xl mb-4">🏆</div>
            <CardTitle className="text-2xl">Game Complete!</CardTitle>
            <CardDescription>You completed all 5 rounds of Jargon Jam</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center">
              <div className="text-4xl font-bold text-orange-600 mb-2">{score}</div>
              <Badge variant="secondary">Final Score</Badge>
            </div>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="text-center">
                <div className="font-semibold">Rounds</div>
                <div className="text-gray-600">5/5</div>
              </div>
              <div className="text-center">
                <div className="font-semibold">Avg per Round</div>
                <div className="text-gray-600">{Math.round(score / 5)}</div>
              </div>
            </div>
            <div className="flex gap-2">
              <Button onClick={initializeGame} className="flex-1">
                <RotateCcw className="h-4 w-4 mr-2" />
                Play Again
              </Button>
              <Link href="/dashboard" className="flex-1">
                <Button variant="outline" className="w-full">
                  <Home className="h-4 w-4 mr-2" />
                  Dashboard
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50 p-4">
      {/* Header */}
      <div className="container mx-auto mb-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Briefcase className="h-6 w-6 text-orange-600" />
            <h1 className="text-2xl font-bold">Jargon Jam</h1>
          </div>
          <Link href="/dashboard">
            <Button variant="outline" size="sm">
              <Home className="h-4 w-4 mr-2" />
              Dashboard
            </Button>
          </Link>
        </div>

        {/* Game Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600 flex items-center justify-center gap-1">
                <Clock className="h-5 w-5" />
                {formatTime(timeLeft)}
              </div>
              <div className="text-sm text-gray-600">Time Left</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-orange-600">{score + roundScore}</div>
              <div className="text-sm text-gray-600">Total Score</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-purple-600">{round}/5</div>
              <div className="text-sm text-gray-600">Round</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600">{userAnswers.length}/5</div>
              <div className="text-sm text-gray-600">Words</div>
            </CardContent>
          </Card>
        </div>

        {/* Progress Bar */}
        <div className="mb-6">
          <Progress value={(userAnswers.length / 5) * 100} className="h-3" />
        </div>
      </div>

      {/* Game Area */}
      <div className="container mx-auto max-w-2xl">
        <Card className="mb-6">
          <CardHeader className="text-center">
            <Badge variant="secondary" className="mb-2">
              {currentWord?.category}
            </Badge>
            <CardTitle className="text-4xl font-bold text-gray-800 mb-4">{currentWord?.word}</CardTitle>
            <CardDescription className="text-lg">
              Name 5 business words related to this term (without using the main word)
            </CardDescription>
            {feedback && <div className="text-lg font-semibold mt-2">{feedback}</div>}
          </CardHeader>
          <CardContent className="space-y-4">
            <form onSubmit={handleSubmitAnswer} className="flex gap-2">
              <Input
                value={currentAnswer}
                onChange={(e) => setCurrentAnswer(e.target.value)}
                placeholder="Enter a related business word..."
                className="text-lg"
                autoFocus
                disabled={userAnswers.length >= 5}
              />
              <Button type="submit" disabled={!currentAnswer.trim() || userAnswers.length >= 5}>
                Add
              </Button>
            </form>

            {/* User Answers */}
            <div className="grid grid-cols-1 gap-2">
              {Array.from({ length: 5 }, (_, index) => (
                <div
                  key={index}
                  className={`p-3 rounded-lg border-2 ${
                    userAnswers[index]
                      ? "bg-green-50 border-green-200 text-green-800"
                      : "bg-gray-50 border-gray-200 text-gray-400"
                  }`}
                >
                  {userAnswers[index] || `Word ${index + 1}...`}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Round Progress */}
        <Card className="bg-gradient-to-r from-orange-100 to-red-100 border-orange-300">
          <CardContent className="p-4 text-center">
            <div className="flex items-center justify-center gap-2">
              <Target className="h-5 w-5 text-orange-600" />
              <span className="font-semibold text-orange-800">
                Round {round} of 5 • Current Round Score: {roundScore}
              </span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
