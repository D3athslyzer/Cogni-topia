"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Calculator, RotateCcw, Home, Trophy, Clock } from "lucide-react"
import Link from "next/link"

interface MathProblem {
  question: string
  answer: number
  options?: number[]
}

export default function SpeedMathGame() {
  const [currentProblem, setCurrentProblem] = useState<MathProblem | null>(null)
  const [userAnswer, setUserAnswer] = useState("")
  const [score, setScore] = useState(0)
  const [streak, setStreak] = useState(0)
  const [timeLeft, setTimeLeft] = useState(60) // 1 minute
  const [problemsCompleted, setProblemsCompleted] = useState(0)
  const [gameStatus, setGameStatus] = useState<"playing" | "finished">("playing")
  const [gameStarted, setGameStarted] = useState(false)
  const [feedback, setFeedback] = useState<"correct" | "incorrect" | null>(null)

  const generateProblem = (): MathProblem => {
    const operations = ["+", "-", "*", "/"]
    const operation = operations[Math.floor(Math.random() * operations.length)]

    let num1: number, num2: number, answer: number, question: string

    switch (operation) {
      case "+":
        num1 = Math.floor(Math.random() * 50) + 1
        num2 = Math.floor(Math.random() * 50) + 1
        answer = num1 + num2
        question = `${num1} + ${num2}`
        break
      case "-":
        num1 = Math.floor(Math.random() * 50) + 25
        num2 = Math.floor(Math.random() * 25) + 1
        answer = num1 - num2
        question = `${num1} - ${num2}`
        break
      case "*":
        num1 = Math.floor(Math.random() * 12) + 1
        num2 = Math.floor(Math.random() * 12) + 1
        answer = num1 * num2
        question = `${num1} × ${num2}`
        break
      case "/":
        answer = Math.floor(Math.random() * 12) + 1
        num2 = Math.floor(Math.random() * 12) + 1
        num1 = answer * num2
        question = `${num1} ÷ ${num2}`
        break
      default:
        num1 = 1
        num2 = 1
        answer = 2
        question = "1 + 1"
    }

    return { question, answer }
  }

  const initializeGame = () => {
    setCurrentProblem(generateProblem())
    setUserAnswer("")
    setScore(0)
    setStreak(0)
    setTimeLeft(60)
    setProblemsCompleted(0)
    setGameStatus("playing")
    setGameStarted(true)
    setFeedback(null)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!currentProblem || !userAnswer.trim()) return

    const userNum = Number.parseInt(userAnswer)
    const isCorrect = userNum === currentProblem.answer

    if (isCorrect) {
      setScore((prev) => prev + (10 + streak * 2))
      setStreak((prev) => prev + 1)
      setFeedback("correct")
    } else {
      setStreak(0)
      setFeedback("incorrect")
    }

    setProblemsCompleted((prev) => prev + 1)

    // Show feedback briefly then move to next problem
    setTimeout(() => {
      setCurrentProblem(generateProblem())
      setUserAnswer("")
      setFeedback(null)
    }, 800)
  }

  // Timer effect
  useEffect(() => {
    if (!gameStarted || gameStatus !== "playing") return

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          setGameStatus("finished")
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [gameStarted, gameStatus])

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const getPerformanceRating = () => {
    const accuracy = problemsCompleted > 0 ? (score / (problemsCompleted * 10)) * 100 : 0
    if (accuracy >= 90) return { rating: "Excellent", color: "text-green-600" }
    if (accuracy >= 75) return { rating: "Good", color: "text-blue-600" }
    if (accuracy >= 60) return { rating: "Fair", color: "text-yellow-600" }
    return { rating: "Needs Practice", color: "text-red-600" }
  }

  if (!gameStarted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md text-center">
          <CardHeader>
            <div className="text-6xl mb-4">🔢</div>
            <CardTitle className="text-2xl">Speed Math</CardTitle>
            <CardDescription>Solve as many math problems as you can in 60 seconds!</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <div className="font-semibold">Time Limit</div>
                <div className="text-gray-600">60 seconds</div>
              </div>
              <div>
                <div className="font-semibold">Operations</div>
                <div className="text-gray-600">+, -, ×, ÷</div>
              </div>
              <div>
                <div className="font-semibold">Scoring</div>
                <div className="text-gray-600">10 + streak bonus</div>
              </div>
              <div>
                <div className="font-semibold">Difficulty</div>
                <div className="text-gray-600">Progressive</div>
              </div>
            </div>
            <Button onClick={initializeGame} className="w-full" size="lg">
              Start Game
            </Button>
            <Link href="/dashboard">
              <Button variant="outline" className="w-full">
                <Home className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (gameStatus === "finished") {
    const performance = getPerformanceRating()

    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md text-center">
          <CardHeader>
            <div className="text-6xl mb-4">
              {performance.rating === "Excellent"
                ? "🏆"
                : performance.rating === "Good"
                  ? "👏"
                  : performance.rating === "Fair"
                    ? "👍"
                    : "💪"}
            </div>
            <CardTitle className="text-2xl">Game Complete!</CardTitle>
            <CardDescription>You solved {problemsCompleted} problems in 60 seconds</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center">
              <div className="text-4xl font-bold text-green-600 mb-2">{score}</div>
              <Badge variant="secondary">Final Score</Badge>
            </div>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="text-center">
                <div className="font-semibold">Problems</div>
                <div className="text-gray-600">{problemsCompleted}</div>
              </div>
              <div className="text-center">
                <div className="font-semibold">Best Streak</div>
                <div className="text-gray-600">{streak}</div>
              </div>
            </div>
            <div className="text-center">
              <div className={`font-semibold ${performance.color}`}>{performance.rating}</div>
            </div>
            <div className="flex gap-2">
              <Button onClick={initializeGame} className="flex-1">
                <RotateCcw className="h-4 w-4 mr-2" />
                Play Again
              </Button>
              <Link href="/dashboard" className="flex-1">
                <Button variant="outline" className="w-full">
                  <Home className="h-4 w-4 mr-2" />
                  Dashboard
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 p-4">
      {/* Header */}
      <div className="container mx-auto mb-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Calculator className="h-6 w-6 text-green-600" />
            <h1 className="text-2xl font-bold">Speed Math</h1>
          </div>
          <Link href="/dashboard">
            <Button variant="outline" size="sm">
              <Home className="h-4 w-4 mr-2" />
              Dashboard
            </Button>
          </Link>
        </div>

        {/* Game Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600 flex items-center justify-center gap-1">
                <Clock className="h-5 w-5" />
                {formatTime(timeLeft)}
              </div>
              <div className="text-sm text-gray-600">Time Left</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600">{score}</div>
              <div className="text-sm text-gray-600">Score</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-orange-600">{streak}</div>
              <div className="text-sm text-gray-600">Streak</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-purple-600">{problemsCompleted}</div>
              <div className="text-sm text-gray-600">Solved</div>
            </CardContent>
          </Card>
        </div>

        {/* Progress Bar */}
        <div className="mb-6">
          <Progress value={((60 - timeLeft) / 60) * 100} className="h-3" />
        </div>
      </div>

      {/* Game Area */}
      <div className="container mx-auto max-w-md">
        <Card className="mb-6">
          <CardHeader className="text-center">
            <CardTitle className="text-4xl font-bold text-gray-800 mb-4">{currentProblem?.question}</CardTitle>
            {feedback && (
              <div className={`text-lg font-semibold ${feedback === "correct" ? "text-green-600" : "text-red-600"}`}>
                {feedback === "correct" ? "✓ Correct!" : "✗ Incorrect"}
              </div>
            )}
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <Input
                type="number"
                value={userAnswer}
                onChange={(e) => setUserAnswer(e.target.value)}
                placeholder="Enter your answer"
                className="text-center text-2xl h-16"
                autoFocus
                disabled={feedback !== null}
              />
              <Button type="submit" className="w-full h-12 text-lg" disabled={!userAnswer.trim() || feedback !== null}>
                Submit Answer
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Streak Indicator */}
        {streak > 0 && (
          <Card className="bg-gradient-to-r from-yellow-100 to-orange-100 border-yellow-300">
            <CardContent className="p-4 text-center">
              <div className="flex items-center justify-center gap-2">
                <Trophy className="h-5 w-5 text-yellow-600" />
                <span className="font-semibold text-yellow-800">{streak} in a row! 🔥</span>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
